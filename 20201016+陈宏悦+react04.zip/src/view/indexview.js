import React from 'react';


export default function IndexView() {
    return <div>
        <img alt="" src={require("../img/img4.png")} className="banner" />
        <div class="wrap">
            <img alt="" src={require("../img/img_1.png")} />
            <img alt="" src={require("../img/img_2.png")} />
        </div>
    </div>
}